package com.jarvis.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    WebView wv;
    TextToSpeech tts;
    boolean ttsOk = false;
    SpeechRecognizer sr;
    boolean noLang = false;
    final Handler h = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF010911);
        getWindow().setNavigationBarColor(0xFF010911);
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALENDAR}, 1);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsOk = true;
                tts.setLanguage(Locale.UK);
                tts.setPitch(0.85f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onDone(String id) { js("window.onNativeSpoken&&onNativeSpoken()"); }
                    @Override public void onError(String id) { js("window.onNativeSpoken&&onNativeSpoken()"); }
                });
            }
        });
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setBackgroundColor(0xFF010911);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient());
        wv.addJavascriptInterface(new Bridge(), "Jarvis");
        wv.loadUrl("file:///android_asset/index.html");
    }

    void js(final String code) {
        h.post(new Runnable() { public void run() { wv.evaluateJavascript(code, null); } });
    }

    void go(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(i); } catch (Exception e) { js("onNativeMsg('Could not do that, sir.')"); }
    }

    void startListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            js("onNativeErr('Microphone permission needed. Allow it in Settings > Apps > Jarvis > Permissions.')");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("onNativeErr('No speech recognition service on this phone, sir.')");
            return;
        }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) {}
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float v) {}
                public void onBufferReceived(byte[] bf) {}
                public void onEndOfSpeech() {}
                public void onPartialResults(Bundle p) {}
                public void onEvent(int t, Bundle p) {}
                public void onResults(Bundle r) {
                    ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (a != null && !a.isEmpty()) js("onNativeSpeech(" + JSONObject.quote(a.get(0)) + ")");
                    else js("onNativeEnd()");
                }
                public void onError(int e) {
                    if ((e == 12 || e == 13) && !noLang) { noLang = true; startListen(); return; }
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || e == SpeechRecognizer.ERROR_CLIENT) js("onNativeEnd()");
                    else js("onNativeErr('Speech error code " + e + ", sir.')");
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        if (!noLang) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false);
        sr.startListening(i);
    }

    class Bridge {
        @JavascriptInterface public void speak(final String t) {
            h.post(new Runnable() { public void run() {
                if (ttsOk) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j");
                else js("window.onNativeSpoken&&onNativeSpoken()");
            }});
        }
        @JavascriptInterface public void stopSpeak() { h.post(new Runnable() { public void run() { if (ttsOk) tts.stop(); } }); }
        @JavascriptInterface public void listen() { h.post(new Runnable() { public void run() { startListen(); } }); }
        @JavascriptInterface public void stopListen() { h.post(new Runnable() { public void run() { if (sr != null) sr.cancel(); } }); }

        @JavascriptInterface public void openApp(final String key, final String url) {
            h.post(new Runnable() { public void run() {
                if ("cam".equals(key)) { go(new Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return; }
                if ("set".equals(key)) { go(new Intent(Settings.ACTION_SETTINGS)); return; }
                if ("dial".equals(key)) { go(new Intent(Intent.ACTION_DIAL)); return; }
                Intent i = key.length() > 0 ? getPackageManager().getLaunchIntentForPackage(key) : null;
                if (i != null) go(i);
                else if (url != null && url.length() > 0) go(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                else js("onNativeMsg('That app is not installed, sir.')");
            }});
        }

        @JavascriptInterface public void whatsapp(final String num, final String msg) {
            h.post(new Runnable() { public void run() {
                Uri u = Uri.parse("https://wa.me/" + num + "?text=" + Uri.encode(msg));
                String[] pk = {"com.whatsapp", "com.whatsapp.w4b"};
                for (String p : pk) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, u);
                        i.setPackage(p);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                        return;
                    } catch (ActivityNotFoundException e) { }
                }
                go(new Intent(Intent.ACTION_VIEW, u));
            }});
        }

        @JavascriptInterface public void call(final String num) {
            h.post(new Runnable() { public void run() {
                boolean ok = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
                go(new Intent(ok ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:+" + num)));
            }});
        }

        @JavascriptInterface public void alarm(final int hr, final int min) {
            h.post(new Runnable() { public void run() {
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                i.putExtra(AlarmClock.EXTRA_HOUR, hr);
                i.putExtra(AlarmClock.EXTRA_MINUTES, min);
                i.putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis");
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                go(i);
            }});
        }

        @JavascriptInterface public void timer(final int sec) {
            h.post(new Runnable() { public void run() {
                Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
                i.putExtra(AlarmClock.EXTRA_LENGTH, sec);
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                go(i);
            }});
        }

        @JavascriptInterface public void agenda(final int startDay, final int span) {
            new Thread(new Runnable() { public void run() {
                if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) { js("onNativeAgenda('null')"); return; }
                try {
                    java.util.Calendar c = java.util.Calendar.getInstance();
                    c.set(java.util.Calendar.HOUR_OF_DAY, 0); c.set(java.util.Calendar.MINUTE, 0);
                    c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0);
                    c.add(java.util.Calendar.DAY_OF_YEAR, startDay);
                    long from = c.getTimeInMillis();
                    c.add(java.util.Calendar.DAY_OF_YEAR, span);
                    long to = c.getTimeInMillis();
                    Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
                    ContentUris.appendId(b, from);
                    ContentUris.appendId(b, to);
                    Cursor cur = getContentResolver().query(b.build(),
                        new String[]{CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY},
                        null, null, CalendarContract.Instances.BEGIN + " ASC");
                    JSONArray arr = new JSONArray();
                    if (cur != null) {
                        while (cur.moveToNext() && arr.length() < 15) {
                            JSONObject o = new JSONObject();
                            o.put("title", cur.getString(0));
                            o.put("begin", cur.getLong(1));
                            o.put("end", cur.getLong(2));
                            o.put("allDay", cur.getInt(3) == 1);
                            arr.put(o);
                        }
                        cur.close();
                    }
                    js("onNativeAgenda(" + JSONObject.quote(arr.toString()) + ")");
                } catch (Exception e) { js("onNativeAgenda('null')"); }
            }}).start();
        }

        @JavascriptInterface public void addEvent(final String title, final double start, final double end) {
            h.post(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI);
                i.putExtra(CalendarContract.Events.TITLE, title);
                i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, (long) start);
                i.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, (long) end);
                go(i);
            }});
        }

        @JavascriptInterface public void torch(final boolean on) {
            h.post(new Runnable() { public void run() {
                try {
                    CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                    cm.setTorchMode(cm.getCameraIdList()[0], on);
                } catch (Exception e) { js("onNativeMsg('Torch is not available, sir.')"); }
            }});
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (sr != null) sr.destroy();
        super.onDestroy();
    }
}
